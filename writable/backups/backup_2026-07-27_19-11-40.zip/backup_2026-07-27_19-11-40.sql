/* Backup Database generato il 2026-07-27 19:11:40 */

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `firstname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lastname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `master` tinyint(1) NOT NULL DEFAULT '0',
  `group_id` int unsigned NOT NULL,
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `suspended_at` datetime DEFAULT NULL,
  `resetted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email_2` (`email`),
  KEY `phone_2` (`phone`),
  KEY `status` (`status`),
  KEY `master` (`master`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `fk_admins_group_id` FOREIGN KEY (`group_id`) REFERENCES `admins_groups` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins` VALUES('3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', 'Francesca', 'Bianchi', 'francesca.bianchi@example.com', '+393001234563', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-20 12:15:05', NULL, NULL, NULL);
INSERT INTO `admins` VALUES('7c4d5b92-f1a8-4e36-9b54-cf210a48b3e9', 'Mario', 'Rossi', 'mario.rossi@example.com', '+393001234561', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-20 12:15:05', NULL, NULL, NULL);
INSERT INTO `admins` VALUES('7e1b5d9c-3a6f-4275-8b9e-c4a2f8d1e3b6', 'Davide', 'Costa', 'davide.costa@example.com', '+393001234576', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-20 12:15:05', NULL, NULL, NULL);
INSERT INTO `admins` VALUES('8b9e1c7d-5a3b-462f-ad4c-1e9b5f2a7c1e', 'Luca', 'Rizzo', 'luca.rizzo@example.com', '+393001234578', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-20 12:15:05', NULL, NULL, '2026-07-20 14:35:20');
INSERT INTO `admins` VALUES('9a5f2c8b-d3e1-4674-bf9e-1c7d5a3b62f4', 'Laura', 'Ricci', 'laura.ricci@example.com', '+393001234569', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-20 12:15:05', NULL, NULL, NULL);
INSERT INTO `admins` VALUES('a6d4e2b8-f1c5-4973-bc8a-4d2e1f5b937c', 'Chiara', 'Gallo', 'chiara.gallo@example.com', '+393001234573', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-20 12:15:05', '2026-07-27 15:16:57', NULL, NULL);
INSERT INTO `admins` VALUES('a83f9e1c-5d2b-4681-ad4e-72bf05c1d63a', 'Giuseppe', 'Verdi', 'giuseppe.verdi@example.com', '+393001234562', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-20 12:15:05', NULL, NULL, NULL);
INSERT INTO `admins` VALUES('b0e3f7d1-c6a4-4893-bc2e-51da9f8b4c72', 'Anna', 'Russo', 'anna.russo@example.com', '+393001234565', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-20 12:15:05', NULL, NULL, NULL);
INSERT INTO `admins` VALUES('bc5f9e1b-5d9c-43a6-8f42-758b9e1c7d5a', 'Andrea', 'Mancini', 'andrea.mancini@example.com', '+393001234580', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-20 12:15:05', NULL, NULL, NULL);
INSERT INTO `admins` VALUES('c1f5b9d3-e2a7-4b61-8d4f-5c9a2e8b637d', 'Elena', 'Romano', 'elena.romano@example.com', '+393001234567', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-20 12:15:05', NULL, NULL, NULL);
INSERT INTO `admins` VALUES('e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'Giorgio', 'Barone', 'gbwebapps@gmail.com', '+393519081161', '1', '1', '1', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-20 12:15:05', '2026-07-24 15:16:09', NULL, '2026-07-24 15:15:44');

DROP TABLE IF EXISTS `admins_2fa`;
CREATE TABLE `admins_2fa` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `method` enum('email','totp') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'email',
  `secret` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_method` (`admin_uuid`,`method`),
  KEY `idx_admin` (`admin_uuid`),
  KEY `idx_admin_enabled` (`admin_uuid`,`enabled`),
  CONSTRAINT `fk_admins_2fa_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_2fa` VALUES('1', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'email', NULL, '0');
INSERT INTO `admins_2fa` VALUES('2', '7c4d5b92-f1a8-4e36-9b54-cf210a48b3e9', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('3', 'a83f9e1c-5d2b-4681-ad4e-72bf05c1d63a', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('4', '3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('6', 'b0e3f7d1-c6a4-4893-bc2e-51da9f8b4c72', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('8', 'c1f5b9d3-e2a7-4b61-8d4f-5c9a2e8b637d', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('10', '9a5f2c8b-d3e1-4674-bf9e-1c7d5a3b62f4', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('14', 'a6d4e2b8-f1c5-4973-bc8a-4d2e1f5b937c', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('17', '7e1b5d9c-3a6f-4275-8b9e-c4a2f8d1e3b6', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('19', '8b9e1c7d-5a3b-462f-ad4c-1e9b5f2a7c1e', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('21', 'bc5f9e1b-5d9c-43a6-8f42-758b9e1c7d5a', 'email', NULL, '1');

DROP TABLE IF EXISTS `admins_2fa_attempts`;
CREATE TABLE `admins_2fa_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `method` enum('email','totp') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ip` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_uuid` (`admin_uuid`,`method`,`timestamp`),
  CONSTRAINT `fk_user_2fa_attempts_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `admins_2fa_codes`;
CREATE TABLE `admins_2fa_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `code` char(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_uuid` (`admin_uuid`),
  CONSTRAINT `fk_admins_2fa_codes_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `admins_attempts`;
CREATE TABLE `admins_attempts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ip` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_attempts_lookup` (`admin_uuid`,`timestamp`),
  CONSTRAINT `fk_admins_attempts_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `admins_audits`;
CREATE TABLE `admins_audits` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Guest',
  `action` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_uuid` (`admin_uuid`),
  KEY `idx_sezione` (`section`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admins_audits` VALUES('166', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_AUDITS', 'tools', 'Eliminazione audits dal 23 luglio 2026 12:00:00 al 29 luglio 2026 12:00:00', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 14:41:18');
INSERT INTO `admins_audits` VALUES('167', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'EDIT_ADMIN', 'admins', 'Aggiornamento admin Chiara Gallo', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:16:57');
INSERT INTO `admins_audits` VALUES('168', NULL, 'Ospite', 'SET_COVER', 'gallery one', 'Impostazione cover.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:17:02');
INSERT INTO `admins_audits` VALUES('169', NULL, 'Ospite', 'SET_COVER', 'gallery one', 'Impostazione cover.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:17:19');
INSERT INTO `admins_audits` VALUES('170', NULL, 'Ospite', 'SET_COVER', 'gallery one', 'Impostazione cover.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:18:28');
INSERT INTO `admins_audits` VALUES('171', NULL, 'Ospite', 'SET_COVER', 'gallery one', 'Impostazione cover.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:21:52');
INSERT INTO `admins_audits` VALUES('172', NULL, 'Ospite', 'SET_COVER', 'gallery one', 'Impostazione cover.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:22:37');
INSERT INTO `admins_audits` VALUES('173', NULL, 'Ospite', 'SET_COVER', 'gallery one', 'Impostazione cover.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:23:48');
INSERT INTO `admins_audits` VALUES('174', NULL, 'Ospite', 'REMOVE_COVER', 'gallery one', 'Rimozione cover.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:23:52');
INSERT INTO `admins_audits` VALUES('175', NULL, 'Ospite', 'SET_COVER', 'gallery one', 'Impostazione cover.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:23:56');
INSERT INTO `admins_audits` VALUES('176', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_TOKEN', 'account', 'Eliminazione token Giorgio Barone', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:25:19');
INSERT INTO `admins_audits` VALUES('177', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_ADMIN', 'admins', 'Eliminazione admin Sara Giordano', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:25:51');
INSERT INTO `admins_audits` VALUES('178', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_ADMIN', 'admins', 'Eliminazione admin Silvia Greco', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:25:54');
INSERT INTO `admins_audits` VALUES('179', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_ADMIN', 'admins', 'Eliminazione admin Alessandro Ferrari', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:25:58');
INSERT INTO `admins_audits` VALUES('180', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_ADMIN', 'admins', 'Eliminazione admin Giulia De Luca', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:26:03');
INSERT INTO `admins_audits` VALUES('181', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'ADD_GROUP', 'groups', 'Aggiunta gruppo Imelda Warner ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:26:32');
INSERT INTO `admins_audits` VALUES('182', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_GROUP', 'groups', 'Eliminazione gruppo Imelda Warner ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:27:18');
INSERT INTO `admins_audits` VALUES('183', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SAVE_EXCEPTIONS', 'groups', 'Inserimento eccezione Francesca Bianchi ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:27:47');
INSERT INTO `admins_audits` VALUES('184', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_SETTINGS', 'settings', 'Eliminazione impostazioni.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:29:40');
INSERT INTO `admins_audits` VALUES('185', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SAVE_SETTINGS', 'settings', 'Salvataggio impostazioni.', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 15:29:51');
INSERT INTO `admins_audits` VALUES('186', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 18:11:40');
INSERT INTO `admins_audits` VALUES('187', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-27 19:09:18');

DROP TABLE IF EXISTS `admins_groups`;
CREATE TABLE `admins_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_groups` VALUES('1', 'Administrator', 'Gestione operativa completa, configurazioni e supervisione utenti', '2026-07-20 12:15:05', NULL);
INSERT INTO `admins_groups` VALUES('2', 'Editor Manager', 'Gestione e pubblicazione dei contenuti, messaggi e schede informative', '2026-07-20 12:15:05', NULL);
INSERT INTO `admins_groups` VALUES('3', 'Operator Support', 'Visualizzazione dati, assistenza clienti e gestione ticket', '2026-07-20 12:15:05', NULL);
INSERT INTO `admins_groups` VALUES('5', 'Grace Reilly', 'Voluptatem ut venia', '2026-07-24 15:27:24', NULL);

DROP TABLE IF EXISTS `admins_groups_permissions`;
CREATE TABLE `admins_groups_permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int unsigned NOT NULL,
  `permission` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_group_permission` (`group_id`,`permission`),
  CONSTRAINT `fk_group_permissions_group_id` FOREIGN KEY (`group_id`) REFERENCES `admins_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_groups_permissions` VALUES('8', '1', 'messages_delete');
INSERT INTO `admins_groups_permissions` VALUES('5', '1', 'messages_index');
INSERT INTO `admins_groups_permissions` VALUES('7', '1', 'messages_show');
INSERT INTO `admins_groups_permissions` VALUES('6', '1', 'messages_showall');
INSERT INTO `admins_groups_permissions` VALUES('4', '1', 'users_delete');
INSERT INTO `admins_groups_permissions` VALUES('1', '1', 'users_index');
INSERT INTO `admins_groups_permissions` VALUES('3', '1', 'users_show');
INSERT INTO `admins_groups_permissions` VALUES('2', '1', 'users_showall');
INSERT INTO `admins_groups_permissions` VALUES('11', '2', 'messages_index');
INSERT INTO `admins_groups_permissions` VALUES('13', '2', 'messages_show');
INSERT INTO `admins_groups_permissions` VALUES('12', '2', 'messages_showall');
INSERT INTO `admins_groups_permissions` VALUES('9', '2', 'users_index');
INSERT INTO `admins_groups_permissions` VALUES('10', '2', 'users_show');
INSERT INTO `admins_groups_permissions` VALUES('15', '3', 'messages_index');
INSERT INTO `admins_groups_permissions` VALUES('16', '3', 'messages_show');
INSERT INTO `admins_groups_permissions` VALUES('14', '3', 'users_index');
INSERT INTO `admins_groups_permissions` VALUES('37', '5', 'messages_delete');
INSERT INTO `admins_groups_permissions` VALUES('36', '5', 'messages_show');
INSERT INTO `admins_groups_permissions` VALUES('35', '5', 'messages_showall');
INSERT INTO `admins_groups_permissions` VALUES('34', '5', 'users_delete');
INSERT INTO `admins_groups_permissions` VALUES('32', '5', 'users_index');
INSERT INTO `admins_groups_permissions` VALUES('33', '5', 'users_show');

DROP TABLE IF EXISTS `admins_permissions`;
CREATE TABLE `admins_permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `permission` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `admin_uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `allow` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_admin_permission` (`admin_uuid`,`permission`),
  CONSTRAINT `fk_admins_permissions_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_permissions` VALUES('2', 'users_delete', '3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', '1');
INSERT INTO `admins_permissions` VALUES('3', 'users_show', '3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', '1');

DROP TABLE IF EXISTS `admins_tokens`;
CREATE TABLE `admins_tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `token_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `token_create` datetime NOT NULL,
  `token_expire` datetime NOT NULL,
  `token_type` enum('cookie','session','activation') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_uuid` (`admin_uuid`),
  KEY `token_hash` (`token_hash`),
  KEY `token_create` (`token_create`),
  KEY `token_expire` (`token_expire`),
  KEY `token_type` (`token_type`),
  CONSTRAINT `fk_admins_tokens_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_tokens` VALUES('17', '8b9e1c7d-5a3b-462f-ad4c-1e9b5f2a7c1e', '367f71d215c135515c349b4b3e782c1858a95cbfecd236bbd289276c5666e04f', '2026-07-20 14:35:20', '2026-07-20 20:35:20', 'activation', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO `admins_tokens` VALUES('84', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', '3a9afec97f735e81965e0be042da2338b787c48cdf0edef4f2e34d9fb917c122', '2026-07-27 19:09:18', '2026-07-27 19:31:40', 'session', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '127.0.0.1');

DROP TABLE IF EXISTS `images`;
CREATE TABLE `images` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `entity_uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_cover` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_images_entity_uuid` (`entity`,`entity_uuid`),
  KEY `idx_images_cover` (`entity`,`entity_uuid`,`is_cover`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `images` VALUES('2', 'admins', 'a6d4e2b8-f1c5-4973-bc8a-4d2e1f5b937c', 'toyota-supra-mk4-mkiv-targa.jpg', '1', '2026-07-27 15:16:57');
INSERT INTO `images` VALUES('3', 'admins', 'a6d4e2b8-f1c5-4973-bc8a-4d2e1f5b937c', 'unnamed-2.jpg', '0', '2026-07-27 15:16:57');

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `timestamp` int unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `sessions` VALUES('ci_session:00198c43574952f3c001ed63014463bb', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785156848;csrf_token_essential|s:32:\"9c0bd72dbe7891c925b0baa54d481aef\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";');
INSERT INTO `sessions` VALUES('ci_session:025456903f87b629ec8f2452ebcc5650', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1784916814;csrf_token_essential|s:32:\"d37d36bcfaca80e70713a5b27c4516df\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"4687bd2a617ecf3bb365e0429e800946\";');
INSERT INTO `sessions` VALUES('ci_session:08bff413bcb5a7ffbc3c384da2cdcc90', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"9a27456453d2b7b3f516c1b6d044a758\";__ci_last_regenerate|i:1785001124;_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"634d4f271d4c21f5777c331da5ecb0f3\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:0dcad285b39712e77df4d2ee33509f1f', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785159647;csrf_token_essential|s:32:\"43e7155fe852c699dcd629e239b9646a\";_ci_previous_url|s:40:\"https://essential.test/backend/dashboard\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:11582225685d018baf146470bf67479f', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785157203;csrf_token_essential|s:32:\"b62e3829a668708f57e46cde83b2f1f4\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:1321885a92d011f68009de85c748d7c4', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"82eb391acf484999041007398f88d0b8\";__ci_last_regenerate|i:1785002151;_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"634d4f271d4c21f5777c331da5ecb0f3\";');
INSERT INTO `sessions` VALUES('ci_session:145f1d8c1d6e535a0c1af9c67200a803', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1784915469;csrf_token_essential|s:32:\"e799da7f975cc29a516efab7110b0e5e\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"4687bd2a617ecf3bb365e0429e800946\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:17f53c35d8322e616eccdf6ea186afa3', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785169506;csrf_token_essential|s:32:\"f6e331b1c7eb1dfb8c1fbb1f858a4fee\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"024f9b865eb3fde5e99b462b137723e3\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:2a02a1249bb46ac8185a63737ab94ac7', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785158878;csrf_token_essential|s:32:\"35d23e29fd6640df2052298f93bd51ef\";_ci_previous_url|s:37:\"https://essential.test/backend/groups\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";');
INSERT INTO `sessions` VALUES('ci_session:3a74b2a70846e4cc1ec9e99f0b15b051', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"3c63dac81a0ca6766f73ce05330b0d5a\";__ci_last_regenerate|i:1785000143;_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"634d4f271d4c21f5777c331da5ecb0f3\";');
INSERT INTO `sessions` VALUES('ci_session:3ed5dd6aa6d149e60c7452adf0d8712f', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785155921;csrf_token_essential|s:32:\"52e9592a93b6ce30dad8701cf658dfe6\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";');
INSERT INTO `sessions` VALUES('ci_session:4425895ada60d262fbbc63c0aadbe4bc', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785170924;csrf_token_essential|s:32:\"bccbc3c2096606b945d7695d032a3644\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"024f9b865eb3fde5e99b462b137723e3\";');
INSERT INTO `sessions` VALUES('ci_session:45199201fb1a5e09e7b2ceeb0ea02710', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"1209acef01cae3586c57413f7769a47e\";__ci_last_regenerate|i:1784907764;_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"e418596803b82771187d31dbd1381049\";');
INSERT INTO `sessions` VALUES('ci_session:49e7e63587d2751ae681efd00b452882', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785160353;csrf_token_essential|s:32:\"a274aa85732ec88872ce1b07cd937b7c\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";');
INSERT INTO `sessions` VALUES('ci_session:4dcd33bf61eb4e65354650144224a631', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1784998614;csrf_token_essential|s:32:\"2f5d9006fdf8b28627dd3b9c01ae4ec1\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"89ea5de59a8306e3005ddd3a30877c64\";');
INSERT INTO `sessions` VALUES('ci_session:52aa9424f397350b5916488ad2336ac3', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"25dfd6ca4cd4dc68d1b5a4e3c23d5c82\";__ci_last_regenerate|i:1784909408;_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"e418596803b82771187d31dbd1381049\";');
INSERT INTO `sessions` VALUES('ci_session:57971fee2bc3455bb4ad36f21720d4ee', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785170924;csrf_token_essential|s:32:\"93066340320238fc4b5d25867f90c936\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"024f9b865eb3fde5e99b462b137723e3\";');
INSERT INTO `sessions` VALUES('ci_session:793c008a5146fcd37abaee56b067d8aa', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"8f1acc305dd27749d199ee7be6cb266e\";__ci_last_regenerate|i:1784906411;_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"e418596803b82771187d31dbd1381049\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:8218fee5bac87ff4e26679307375a95d', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"aa56777fd357bb583df3e5853a8a4234\";__ci_last_regenerate|i:1785001472;_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"634d4f271d4c21f5777c331da5ecb0f3\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:88142c189c34464b418128eb8f7cb0d4', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785172158;csrf_token_essential|s:32:\"6b86e831ebb8f2c9da77e17baaaf896b\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"b844152b68be033a2944082eeb2535e2\";');
INSERT INTO `sessions` VALUES('ci_session:952c0baa5aa50881dc01c35b59b56ace', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785158041;csrf_token_essential|s:32:\"43ee2ba830afd8db35fd46ae7de1c326\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:aa27dc76959642049b6a101fe9e6db26', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785158508;csrf_token_essential|s:32:\"86452b521777c4533f65b5800e7f275f\";_ci_previous_url|s:79:\"https://essential.test/backend/admins/show/a6d4e2b8-f1c5-4973-bc8a-4d2e1f5b937c\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:c3c605fe470e7becbf7f091cc8fb176b', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785160688;csrf_token_essential|s:32:\"59b63181e33f8028bece9a75c79c029e\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";');
INSERT INTO `sessions` VALUES('ci_session:c46be3983584bba55a119522df70846b', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"7357ee6f579bea9869d7176a5627c854\";__ci_last_regenerate|i:1785002783;_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"634d4f271d4c21f5777c331da5ecb0f3\";');
INSERT INTO `sessions` VALUES('ci_session:c53c10b665374656dd25285c3d6ad410', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785162433;csrf_token_essential|s:32:\"1dea7764878e2a0435db601e26bcc0a9\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:d13757d1a702a8cf3f4a23d38ee3ba5f', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785161780;csrf_token_essential|s:32:\"6f1e1ff32af6308a7af914f072b247f8\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";');
INSERT INTO `sessions` VALUES('ci_session:d1ccb17d3ce8f497d7c3826005fdb8fd', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785157738;csrf_token_essential|s:32:\"f2701f9fca0ecc09875ac6b4c76c1018\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:dad49cc32729adf8bf98ff22220a9257', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785168691;csrf_token_essential|s:32:\"f9d7d0312f03452a71ab28ce50f8860f\";_ci_previous_url|s:37:\"https://essential.test/backend/audits\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";intended_url|s:37:\"https://essential.test/backend/audits\";message|s:33:\"Effettuare il login per accedere.\";__ci_vars|a:3:{s:7:\"message\";s:3:\"new\";s:5:\"class\";s:3:\"new\";s:4:\"icon\";s:3:\"new\";}class|s:6:\"danger\";icon|s:48:\"<i class=\"fa-solid fa-triangle-exclamation\"></i>\";');
INSERT INTO `sessions` VALUES('ci_session:ef0b252f6d14fd43309392cf01e2625b', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785161465;csrf_token_essential|s:32:\"b9325312930c8b2d9b1c8a049e7ffa5d\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";');
INSERT INTO `sessions` VALUES('ci_session:f1ad2e35068191c97c6ce5d65461b7cc', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785161044;csrf_token_essential|s:32:\"8140fbba15d06f1b101d4148d179d6a5\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"0dc86c4b1358cf5aed74a1012598a873\";');

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `class_key_unique` (`class`,`key`),
  KEY `idx_class` (`class`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` VALUES('15', 'Backend\\Upload', 'renameImages', '0', '2026-07-21 19:27:54', '2026-07-23 17:22:39');
INSERT INTO `settings` VALUES('16', 'Backend\\Upload', 'overwriteImages', '0', '2026-07-21 19:27:54', '2026-07-23 17:22:39');
INSERT INTO `settings` VALUES('17', 'Backend\\Upload', 'cropCenter', '1', '2026-07-21 19:27:54', '2026-07-23 17:22:39');
INSERT INTO `settings` VALUES('18', 'Backend\\Upload', 'maxFileSize', '4096', '2026-07-21 19:27:54', '2026-07-23 17:22:39');
INSERT INTO `settings` VALUES('19', 'Backend\\Upload', 'allowedExtensions', 'png|jpg|jpeg|webp|avif', '2026-07-21 19:27:54', '2026-07-23 17:22:39');
INSERT INTO `settings` VALUES('20', 'Backend\\Upload', 'maxImageX', '1920', '2026-07-21 19:27:54', '2026-07-23 17:22:39');
INSERT INTO `settings` VALUES('21', 'Backend\\Upload', 'maxImageY', '1080', '2026-07-21 19:27:54', '2026-07-23 17:22:39');
INSERT INTO `settings` VALUES('22', 'Backend\\Upload', 'resizeMediumX', '960', '2026-07-21 19:27:54', '2026-07-23 17:22:39');
INSERT INTO `settings` VALUES('23', 'Backend\\Upload', 'resizeMediumY', '540', '2026-07-21 19:27:54', '2026-07-23 17:22:39');
INSERT INTO `settings` VALUES('24', 'Backend\\Upload', 'resizeSmallX', '96', '2026-07-21 19:27:54', '2026-07-23 17:22:39');
INSERT INTO `settings` VALUES('25', 'Backend\\Upload', 'resizeSmallY', '54', '2026-07-21 19:27:54', '2026-07-23 17:22:39');
INSERT INTO `settings` VALUES('26', 'Backend\\Email', 'fromEmail', 'essential@essential.com', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('27', 'Backend\\Email', 'fromName', 'Essential', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('28', 'Backend\\Email', 'recipients', '', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('29', 'Backend\\Email', 'protocol', 'smtp', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('30', 'Backend\\Email', 'SMTPHost', 'sandbox.smtp.mailtrap.io', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('31', 'Backend\\Email', 'SMTPPort', '2525', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('32', 'Backend\\Email', 'SMTPCrypto', 'tls', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('33', 'Backend\\Email', 'SMTPUser', '2136f4b6976b87', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('34', 'Backend\\Email', 'SMTPPass', 'e866a6da928c72', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('35', 'Backend\\Email', 'SMTPAuthMethod', 'LOGIN', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('36', 'Backend\\Email', 'mailType', 'html', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('37', 'Backend\\Email', 'charset', 'UTF-8', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('38', 'Backend\\Email', 'priority', '3', '2026-07-21 19:28:13', '2026-07-21 19:28:13');
INSERT INTO `settings` VALUES('68', 'Backend\\Auth', 'attempts', '1', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('69', 'Backend\\Auth', 'attemptsLimit', '3', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('70', 'Backend\\Auth', 'attemptsInterval', '600', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('71', 'Backend\\Auth', 'twoFactor', '1', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('72', 'Backend\\Auth', 'twoFactorLimit', '3', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('73', 'Backend\\Auth', 'twoFactorTime', '600', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('74', 'Backend\\Auth', 'twoFactorIssuer', 'Essential', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('75', 'Backend\\Auth', 'twoFactorDigits', '6', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('76', 'Backend\\Auth', 'twoFactorWindow', '1', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('77', 'Backend\\Auth', 'twoFactorEmailExpiry', '60', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('78', 'Backend\\Auth', 'twoFactorEmailFrom', 'master@essential.it', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('79', 'Backend\\Auth', 'sessionTime', '1200', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('80', 'Backend\\Auth', 'rememberMeTime', '86400', '2026-07-27 15:29:51', '2026-07-27 15:29:51');
INSERT INTO `settings` VALUES('81', 'Backend\\Auth', 'activationTime', '21600', '2026-07-27 15:29:51', '2026-07-27 15:29:51');

SET FOREIGN_KEY_CHECKS = 1;
