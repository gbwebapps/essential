/* Backup Database generato il 2026-08-06 19:44:14 */

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `master` tinyint(1) NOT NULL DEFAULT '0',
  `group_id` int unsigned NOT NULL,
  `note` text COLLATE utf8mb4_general_ci,
  `password_hash` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `suspended_at` datetime DEFAULT NULL,
  `resetted_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `email` (`email`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email_2` (`email`),
  KEY `phone` (`phone`),
  KEY `status` (`status`),
  KEY `master` (`master`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `fk_admins_group_id` FOREIGN KEY (`group_id`) REFERENCES `admins_groups` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins` VALUES('3a6f4275-8b9e-41c4-bc2f-d3e1b7d6e4a5', 'Martina', 'Moretti', 'martina.moretti@example.com', '+393001234579', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, '2026-08-03 17:43:56', NULL);
INSERT INTO `admins` VALUES('3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', 'Francesca', 'Bianchi', 'francesca.bianchi@example.com', '+393001234563', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, '2026-08-04 18:12:45', NULL);
INSERT INTO `admins` VALUES('4e8b3c1d-fa62-4935-bc71-2e5a9f4b8d63', 'Stefano', 'Colombo', 'stefano.colombo@example.com.deleted.1786038048', '+393001234568', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, '2026-08-06 19:40:48');
INSERT INTO `admins` VALUES('5f2a1d7c-e9b4-4361-8c5f-9d3a7b6e84fa', 'Fabio', 'Bruno', 'fabio.bruno@example.com', '+393001234572', '0', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', '2026-08-06 19:40:40', '2026-08-06 19:40:40', NULL, NULL);
INSERT INTO `admins` VALUES('6d2a8f4c-1e9b-4375-ae82-93b5c1d6f47a', 'Roberto', 'Esposito', 'roberto.esposito@example.com', '+393001234566', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, '2026-08-04 18:12:21', NULL);
INSERT INTO `admins` VALUES('7c4d5b92-f1a8-4e36-9b54-cf210a48b3e9', 'Mario', 'Rossi', 'mario.rossi@example.com', '+393001234561', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('7e1b5d9c-3a6f-4275-8b9e-c4a2f8d1e3b6', 'Davide', 'Costa', 'davide.costa@example.com', '+393001234576', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('8b9e1c7d-5a3b-462f-ad4c-1e9b5f2a7c1e', 'Luca', 'Rizzo', 'luca.rizzo@example.com', '+393001234578', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('9a5f2c8b-d3e1-4674-bf9e-1c7d5a3b62f4', 'Laura', 'Ricci', 'laura.ricci@example.com', '+393001234569', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('a6d4e2b8-f1c5-4973-bc8a-4d2e1f5b937c', 'Chiara', 'Gallo', 'chiara.gallo@example.com', '+393001234573', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('a83f9e1c-5d2b-4681-ad4e-72bf05c1d63a', 'Giuseppe', 'Verdi', 'giuseppe.verdi@example.com', '+393001234562', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('b0e3f7d1-c6a4-4893-bc2e-51da9f8b4c72', 'Anna', 'Russo', 'anna.russo@example.com', '+393001234565', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('bc5f9e1b-5d9c-43a6-8f42-758b9e1c7d5a', 'Andrea', 'Mancini', 'andrea.mancini@example.com', '+393001234580', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('c1f5b9d3-e2a7-4b61-8d4f-5c9a2e8b637d', 'Elena', 'Romano', 'elena.romano@example.com', '+393001234567', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('c4a2f8d1-e3b6-4927-bc5f-9e1b5d9c3a6f', 'Sara', 'Giordano', 'sara.giordano@example.com', '+393001234577', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('e3c9a5b7-2f1d-4862-ad7e-6b4c1f9e2a5d', 'Silvia', 'Greco', 'silvia.greco@example.com', '+393001234571', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'Giorgio Alessandro', 'Barone', 'gbwebapps@gmail.com', '+393519081161', '1', '1', '1', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', '2026-08-06 14:54:47', NULL, NULL, NULL);
INSERT INTO `admins` VALUES('f2c5a1e8-73b9-4d62-9a4f-1c8b5d3e76fa', 'Alessandro', 'Ferrari', 'alessandro.ferrari@example.com', '+393001234564', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('fd3a7c1e-9b5f-4628-ad12-5e4c8a7b3f91', 'Giulia', 'De Luca', 'giulia.deluca@example.com', '+393001234575', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-08-03 15:14:28', NULL, NULL, NULL, NULL);

DROP TABLE IF EXISTS `admins_2fa`;
CREATE TABLE `admins_2fa` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `method` enum('email','totp') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'email',
  `secret` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_method` (`admin_uuid`,`method`),
  KEY `idx_admin` (`admin_uuid`),
  KEY `idx_admin_enabled` (`admin_uuid`,`enabled`),
  CONSTRAINT `fk_admins_2fa_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_2fa` VALUES('1', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'email', NULL, '0');
INSERT INTO `admins_2fa` VALUES('2', '7c4d5b92-f1a8-4e36-9b54-cf210a48b3e9', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('3', 'a83f9e1c-5d2b-4681-ad4e-72bf05c1d63a', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('4', '3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('5', 'f2c5a1e8-73b9-4d62-9a4f-1c8b5d3e76fa', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('6', 'b0e3f7d1-c6a4-4893-bc2e-51da9f8b4c72', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('7', '6d2a8f4c-1e9b-4375-ae82-93b5c1d6f47a', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('8', 'c1f5b9d3-e2a7-4b61-8d4f-5c9a2e8b637d', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('9', '4e8b3c1d-fa62-4935-bc71-2e5a9f4b8d63', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('10', '9a5f2c8b-d3e1-4674-bf9e-1c7d5a3b62f4', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('12', 'e3c9a5b7-2f1d-4862-ad7e-6b4c1f9e2a5d', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('13', '5f2a1d7c-e9b4-4361-8c5f-9d3a7b6e84fa', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('14', 'a6d4e2b8-f1c5-4973-bc8a-4d2e1f5b937c', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('16', 'fd3a7c1e-9b5f-4628-ad12-5e4c8a7b3f91', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('17', '7e1b5d9c-3a6f-4275-8b9e-c4a2f8d1e3b6', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('18', 'c4a2f8d1-e3b6-4927-bc5f-9e1b5d9c3a6f', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('19', '8b9e1c7d-5a3b-462f-ad4c-1e9b5f2a7c1e', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('20', '3a6f4275-8b9e-41c4-bc2f-d3e1b7d6e4a5', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('21', 'bc5f9e1b-5d9c-43a6-8f42-758b9e1c7d5a', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('22', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'totp', 'VSBEDA7CW4LI6RWXOYEIKU5IKWFREJM767BJO5KQVPUVV2MP4TG4CON3I22IS64JOULVCSAI5XK6FHVVJCXFU7PNTEUZSKM7LLBJMBI', '0');

DROP TABLE IF EXISTS `admins_2fa_attempts`;
CREATE TABLE `admins_2fa_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `method` enum('email','totp') COLLATE utf8mb4_general_ci NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_uuid` (`admin_uuid`,`method`,`timestamp`),
  CONSTRAINT `fk_user_2fa_attempts_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `admins_2fa_codes`;
CREATE TABLE `admins_2fa_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `code` char(6) COLLATE utf8mb4_general_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_uuid` (`admin_uuid`),
  CONSTRAINT `fk_admins_2fa_codes_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `admins_attempts`;
CREATE TABLE `admins_attempts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_attempts_lookup` (`admin_uuid`,`timestamp`),
  CONSTRAINT `fk_admins_attempts_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `admins_audits`;
CREATE TABLE `admins_audits` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Guest',
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_uuid` (`admin_uuid`),
  KEY `idx_sezione` (`section`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admins_audits` VALUES('97', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_AUDITS', 'tools', 'Eliminazione audits dal 2 agosto 2026 12:00:00 al 8 agosto 2026 12:00:00', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 17:38:21');
INSERT INTO `admins_audits` VALUES('98', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 18:01:34');
INSERT INTO `admins_audits` VALUES('99', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'OPTIMIZE_DB', 'tools', 'Eseguita ottimizzazione su tutte le tabelle del database', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 18:02:21');
INSERT INTO `admins_audits` VALUES('100', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'GENERATE_BACKUP', 'tools', 'Generato nuovo backup del database: backup_2026-08-06_18-02-37.zip', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 18:02:37');
INSERT INTO `admins_audits` VALUES('101', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_BACKUP', 'tools', 'Eliminato backup del database: backup_2026-07-27_19-11-40.zip', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 18:02:52');
INSERT INTO `admins_audits` VALUES('102', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_BACKUP', 'tools', 'Eliminato backup del database: backup_2026-07-28_11-54-38.zip', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 18:02:55');
INSERT INTO `admins_audits` VALUES('103', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_BACKUP', 'tools', 'Eliminato backup del database: backup_2026-07-30_17-59-46.zip', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 18:02:58');
INSERT INTO `admins_audits` VALUES('104', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 19:30:38');
INSERT INTO `admins_audits` VALUES('105', '6d2a8f4c-1e9b-4375-ae82-93b5c1d6f47a', 'roberto.esposito@example.com', '2FA_REQUIRED', 'auth', 'Richiesto codice di verifica 2FA (email) Roberto Esposito', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '2026-08-06 19:33:31');
INSERT INTO `admins_audits` VALUES('106', '6d2a8f4c-1e9b-4375-ae82-93b5c1d6f47a', 'roberto.esposito@example.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Roberto Esposito ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0', '2026-08-06 19:33:53');
INSERT INTO `admins_audits` VALUES('107', '3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', 'francesca.bianchi@example.com', '2FA_REQUIRED', 'auth', 'Richiesto codice di verifica 2FA (email) Francesca Bianchi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0', '2026-08-06 19:35:13');
INSERT INTO `admins_audits` VALUES('108', '3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', 'francesca.bianchi@example.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Francesca Bianchi ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0', '2026-08-06 19:35:36');
INSERT INTO `admins_audits` VALUES('109', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'EXPORT_DATA', 'admins_tokens', 'Esportazione dati dalla tabella: admins_tokens', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 19:36:33');
INSERT INTO `admins_audits` VALUES('110', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_TOKEN', 'tokens', 'Delete token Francesca Bianchi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 19:38:05');
INSERT INTO `admins_audits` VALUES('111', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_TOKEN', 'tokens', 'Delete token Roberto Esposito', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 19:38:27');
INSERT INTO `admins_audits` VALUES('112', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'CHANGE_STATUS_ADMIN', 'admins', 'Aggiornamento status Fabio Bruno', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 19:40:41');
INSERT INTO `admins_audits` VALUES('113', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE_ADMINS', 'admins', 'Cestinato admin Stefano Colombo', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-08-06 19:40:48');

DROP TABLE IF EXISTS `admins_groups`;
CREATE TABLE `admins_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_groups` VALUES('1', 'Administrator', 'Gestione operativa completa, configurazioni e supervisione utenti', '2026-08-03 15:14:28', NULL);
INSERT INTO `admins_groups` VALUES('2', 'Editor Manager', 'Gestione e pubblicazione dei contenuti, messaggi e schede informative', '2026-08-03 15:14:28', NULL);
INSERT INTO `admins_groups` VALUES('3', 'Operator Support', 'Visualizzazione dati, assistenza clienti e gestione ticket', '2026-08-03 15:14:28', NULL);

DROP TABLE IF EXISTS `admins_groups_permissions`;
CREATE TABLE `admins_groups_permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int unsigned NOT NULL,
  `permission` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_group_permission` (`group_id`,`permission`),
  CONSTRAINT `fk_group_permissions_group_id` FOREIGN KEY (`group_id`) REFERENCES `admins_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_groups_permissions` VALUES('8', '1', 'messages_delete');
INSERT INTO `admins_groups_permissions` VALUES('5', '1', 'messages_index');
INSERT INTO `admins_groups_permissions` VALUES('7', '1', 'messages_show');
INSERT INTO `admins_groups_permissions` VALUES('6', '1', 'messages_showall');
INSERT INTO `admins_groups_permissions` VALUES('4', '1', 'users_delete');
INSERT INTO `admins_groups_permissions` VALUES('1', '1', 'users_index');
INSERT INTO `admins_groups_permissions` VALUES('3', '1', 'users_show');
INSERT INTO `admins_groups_permissions` VALUES('2', '1', 'users_showall');
INSERT INTO `admins_groups_permissions` VALUES('11', '2', 'messages_index');
INSERT INTO `admins_groups_permissions` VALUES('13', '2', 'messages_show');
INSERT INTO `admins_groups_permissions` VALUES('12', '2', 'messages_showall');
INSERT INTO `admins_groups_permissions` VALUES('9', '2', 'users_index');
INSERT INTO `admins_groups_permissions` VALUES('10', '2', 'users_show');
INSERT INTO `admins_groups_permissions` VALUES('15', '3', 'messages_index');
INSERT INTO `admins_groups_permissions` VALUES('16', '3', 'messages_show');
INSERT INTO `admins_groups_permissions` VALUES('14', '3', 'users_index');

DROP TABLE IF EXISTS `admins_permissions`;
CREATE TABLE `admins_permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `permission` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `allow` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_admin_permission` (`admin_uuid`,`permission`),
  CONSTRAINT `fk_admins_permissions_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `admins_tokens`;
CREATE TABLE `admins_tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `token_hash` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `token_create` datetime NOT NULL,
  `token_expire` datetime NOT NULL,
  `token_type` enum('cookie','session','activation') COLLATE utf8mb4_general_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_uuid` (`admin_uuid`),
  KEY `token_hash` (`token_hash`),
  KEY `token_create` (`token_create`),
  KEY `token_expire` (`token_expire`),
  KEY `token_type` (`token_type`),
  CONSTRAINT `fk_admins_tokens_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_tokens` VALUES('19', '6d2a8f4c-1e9b-4375-ae82-93b5c1d6f47a', '47fdb5862e6c11e41f401981346dcae07a33c742140b1b5b62dcacae53449213', '2026-08-04 18:12:21', '2026-08-05 00:12:21', 'activation', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '127.0.0.1', '2026-08-04 18:12:21');
INSERT INTO `admins_tokens` VALUES('20', '3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', 'a01c2b10f17eb6741ff179bd7724efa5fe6d3d213aae6e028e9d22cd61f0cd35', '2026-08-04 18:12:45', '2026-08-05 00:12:45', 'activation', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '127.0.0.1', '2026-08-04 18:12:45');
INSERT INTO `admins_tokens` VALUES('32', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'b7dd76fc7cadb8f3cca02503a753d2e071bfc45187e6bebab2aa93be7ae73251', '2026-08-06 19:30:38', '2026-08-06 20:04:14', 'session', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '127.0.0.1', '2026-08-06 19:30:38');

DROP TABLE IF EXISTS `images`;
CREATE TABLE `images` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `entity_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `is_cover` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_images_entity_uuid` (`entity`,`entity_uuid`),
  KEY `idx_images_cover` (`entity`,`entity_uuid`,`is_cover`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(128) COLLATE utf8mb4_general_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `timestamp` int unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `sessions` VALUES('ci_session:009ffbed4e6b3a6d442eddf4b7664b92', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785779735;csrf_token_essential|s:32:\"40d1601958c79db32bfbc6253df4d369\";_ci_previous_url|s:79:\"https://essential.test/backend/admins/show/1b7d6e4a-c5f9-4283-9b4e-8d2a1c5f3b76\";backendSession|s:32:\"cde491837c5d5ece82ebcbaca723697b\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:02a06469e219d1462368ae94a7b81ec7', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786025505;csrf_token_essential|s:32:\"6f93cc1113f75d801cb327e3e98e8b92\";_ci_previous_url|s:37:\"https://essential.test/backend/audits\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:0325f945781ea3770fc674bcd5acf84a', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785771320;csrf_token_essential|s:32:\"6bd98df007d33482510ad46bd96ac492\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"d08024373f31120f572daf6682f0f582\";');
INSERT INTO `sessions` VALUES('ci_session:06993ff7d3a1c35e4a412c9927480061', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785847968;csrf_token_essential|s:32:\"636a0537efd99e7a9594477b4dae12c5\";_ci_previous_url|s:40:\"https://essential.test/backend/dashboard\";backendSession|s:32:\"4325b00bb8eb94b0e5fe5d2044eb738e\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:09224ec6148e76034567c97f69774d87', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786021232;csrf_token_essential|s:32:\"45779f1817293e5e3084d3bf85920818\";_ci_previous_url|s:37:\"https://essential.test/backend/audits\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:0b335e62c55d0b316de3f07c299bfc17', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785774158;csrf_token_essential|s:32:\"77fce933587ccc613d954be90b1f1fef\";_ci_previous_url|s:79:\"https://essential.test/backend/admins/show/1b7d6e4a-c5f9-4283-9b4e-8d2a1c5f3b76\";backendSession|s:32:\"955091d88a6724c6e94bb95e0d6e18c0\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:0bda8d527f2287b57092c34f8d6c0cc5', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786024769;csrf_token_essential|s:32:\"a29b62859d13b541f6c1d948ed31b581\";_ci_previous_url|s:37:\"https://essential.test/backend/audits\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:1245a41c757ba76d395acd7f186505b3', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786037793;csrf_token_essential|s:32:\"347d5bec48cd07c598aa429e0898486a\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"2d4df4b587a60a1fe36a1adef896824b\";');
INSERT INTO `sessions` VALUES('ci_session:188340edb52f38e1bd1cf1aa27470b3c', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785854508;csrf_token_essential|s:32:\"5ade6e7f0738654ac936b47616946eb1\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";');
INSERT INTO `sessions` VALUES('ci_session:1ee132e268c43dda536ac71960f67d83', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785850614;csrf_token_essential|s:32:\"3c17a3dc738b4522bb2626c604deaddf\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";');
INSERT INTO `sessions` VALUES('ci_session:2154c881e98af3dd381ecaf9778188ea', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786029340;csrf_token_essential|s:32:\"917746834b8dc20d8b533c0cde95dfc8\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"e4212bcff88ec2fbd101e03fe1ac6531\";message|s:33:\"Effettuare il login per accedere.\";__ci_vars|a:3:{s:7:\"message\";s:3:\"new\";s:5:\"class\";s:3:\"new\";s:4:\"icon\";s:3:\"new\";}class|s:25:\"light text-danger fw-bold\";icon|s:48:\"<i class=\"fa-solid fa-triangle-exclamation\"></i>\";');
INSERT INTO `sessions` VALUES('ci_session:2d3799130a3a47724ec796bd1287f2ed', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785779731;csrf_token_essential|s:32:\"a54bb625896b7e12ed184d26d32b7521\";_ci_previous_url|s:79:\"https://essential.test/backend/admins/show/1b7d6e4a-c5f9-4283-9b4e-8d2a1c5f3b76\";backendSession|s:32:\"806c92f11d06acaed5d0c13abb09699d\";message|s:33:\"Effettuare il login per accedere.\";__ci_vars|a:3:{s:7:\"message\";s:3:\"new\";s:5:\"class\";s:3:\"new\";s:4:\"icon\";s:3:\"new\";}class|s:25:\"light text-danger fw-bold\";icon|s:48:\"<i class=\"fa-solid fa-triangle-exclamation\"></i>\";');
INSERT INTO `sessions` VALUES('ci_session:2e206c1317f3460634c5c9878613c103', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785772468;csrf_token_essential|s:32:\"17c77cde3acd0ce96130ad150263599e\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"be6f8c27ad3005db08e391a1e5f886ac\";');
INSERT INTO `sessions` VALUES('ci_session:2f35a1158750384ad5d6516bbcacf910', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785938785;csrf_token_essential|s:32:\"4f1a63725a291a437a36ac8a59f2ecd3\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"5c8c553613730a2ebc2324bd09b2b032\";intended_url|s:45:\"https://essential.test/backend/admins/showAll\";message|s:33:\"Effettuare il login per accedere.\";__ci_vars|a:3:{s:7:\"message\";s:3:\"new\";s:5:\"class\";s:3:\"new\";s:4:\"icon\";s:3:\"new\";}class|s:25:\"light text-danger fw-bold\";icon|s:48:\"<i class=\"fa-solid fa-triangle-exclamation\"></i>\";');
INSERT INTO `sessions` VALUES('ci_session:2f92d7635d38d08a35c84ca960471bfb', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786024062;csrf_token_essential|s:32:\"f61020f1901deabe575b7f9e8687c5bd\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:342810482bd0a82b3cb58b4542286fab', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786023341;csrf_token_essential|s:32:\"8a1053b2ca6f4461c38817f81c49e706\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:359ef145d6cd567b9220b31a15870278', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785850300;csrf_token_essential|s:32:\"c28d21082e1446dd97ee26457f95b1dc\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";');
INSERT INTO `sessions` VALUES('ci_session:3acb75e4fc6f5a4f4f2018d9af19d2ed', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785777393;csrf_token_essential|s:32:\"ad2940dab5734c2851ba77d83c02fcfc\";_ci_previous_url|s:79:\"https://essential.test/backend/admins/show/1b7d6e4a-c5f9-4283-9b4e-8d2a1c5f3b76\";backendSession|s:32:\"806c92f11d06acaed5d0c13abb09699d\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:3ad385c0c23f2de543a74f0d1ddcb841', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785847140;csrf_token_essential|s:32:\"a13a179a7b563188368858321c7f6d63\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"4325b00bb8eb94b0e5fe5d2044eb738e\";');
INSERT INTO `sessions` VALUES('ci_session:3da29362d0cda8029d176babb52db926', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785935751;csrf_token_essential|s:32:\"7eb8b4590f2cc9c34a6555408d5ebe84\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"5c8c553613730a2ebc2324bd09b2b032\";');
INSERT INTO `sessions` VALUES('ci_session:3eea93dd817cec6569424f13096ed931', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785937529;csrf_token_essential|s:32:\"b8cc2dc97b32c7d31adc133a59c14486\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"5c8c553613730a2ebc2324bd09b2b032\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:48984a74045ad097b91d85d4b417bfe2', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785935370;csrf_token_essential|s:32:\"c35c263beb8cd50654f263d377c541d9\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"5c8c553613730a2ebc2324bd09b2b032\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:4c485bf548ccdb2328fe619d535e3144', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786038123;csrf_token_essential|s:32:\"89999eb95f2c756ec8282ee3506b79c6\";_ci_previous_url|s:79:\"https://essential.test/backend/admins/show/3a6f4275-8b9e-41c4-bc2f-d3e1b7d6e4a5\";backendSession|s:32:\"2d4df4b587a60a1fe36a1adef896824b\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:4f9a6f21a4537517ed1e2d6435968659', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785936929;csrf_token_essential|s:32:\"b7c4e528c5835a0f280cd076bdad8646\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"5c8c553613730a2ebc2324bd09b2b032\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:4fe14ace2210e3dd0b5e259453dccfa9', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785939156;csrf_token_essential|s:32:\"5ca238576bde2ba849e5d824eeb7f604\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"8b8e4388a67403dfc578997d52a5d94f\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:52e35a2cd7b9ff70523fe8185c92680c', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785853847;csrf_token_essential|s:32:\"0760d7f4b8f224c2ea50508885123b85\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";');
INSERT INTO `sessions` VALUES('ci_session:577887dd737df56b29bae74904aacc04', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785773220;csrf_token_essential|s:32:\"e39d6026c3893906eb827a55128c523b\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"be6f8c27ad3005db08e391a1e5f886ac\";');
INSERT INTO `sessions` VALUES('ci_session:581675ad21c96c51adaa379c2849d647', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785777072;csrf_token_essential|s:32:\"662f8ebc76263ebc5c37f2e431ac905d\";_ci_previous_url|s:79:\"https://essential.test/backend/admins/show/1b7d6e4a-c5f9-4283-9b4e-8d2a1c5f3b76\";backendSession|s:32:\"806c92f11d06acaed5d0c13abb09699d\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:5a3378cd831236f442b410ee2a826723', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785941776;csrf_token_essential|s:32:\"55404e5f034cdfc711dc462cdc63a0cc\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"8b8e4388a67403dfc578997d52a5d94f\";');
INSERT INTO `sessions` VALUES('ci_session:6295237747b430c49aaa64ca96003839', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785856158;csrf_token_essential|s:32:\"a842f496d183611d3ff72cf07e6cf7ea\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";');
INSERT INTO `sessions` VALUES('ci_session:639a207d8a4508df794c856544fd38a9', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785939610;csrf_token_essential|s:32:\"f1656b1c064b8a32ba41d6f27baa49ba\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"8b8e4388a67403dfc578997d52a5d94f\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:64d08fa7e9d2b65ce469d121293aa3c3', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785940293;csrf_token_essential|s:32:\"94b2497483ca71f33fc6484f018d9366\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"8b8e4388a67403dfc578997d52a5d94f\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:660662b58b0e3101ce43886a610f776f', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786021539;csrf_token_essential|s:32:\"eaea731c6ddeda172875d4ba4905145f\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:67a751f136c6bddba367cc0e12730eb3', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786027761;csrf_token_essential|s:32:\"8e137d30eac77eedabc360126ac54bdc\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:68f49e817f2aff0c9cbdf69d0fcccd57', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785942393;csrf_token_essential|s:32:\"f8f064345fbbc29a933693a0f5a5915e\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"8b8e4388a67403dfc578997d52a5d94f\";');
INSERT INTO `sessions` VALUES('ci_session:69948b561a28af023cdddf38784ce66a', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785856560;csrf_token_essential|s:32:\"c3aefd561d27cf8e1ad0f85cba7a30d4\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";');
INSERT INTO `sessions` VALUES('ci_session:6a3c5c0a62dc5a561c20b379ac22a348', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785935034;csrf_token_essential|s:32:\"fd774ec20e60a815803fb3e801d59f1e\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"5c8c553613730a2ebc2324bd09b2b032\";');
INSERT INTO `sessions` VALUES('ci_session:6c6a040f98a32309bca2787b98bf5c45', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785940641;csrf_token_essential|s:32:\"21e4471d505e23585484419f127e7a64\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"8b8e4388a67403dfc578997d52a5d94f\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:701ba33b81dbf161c24e2a8df87addda', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785942080;csrf_token_essential|s:32:\"645bbc1ab5a9477bcc236afb6a9af632\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"8b8e4388a67403dfc578997d52a5d94f\";');
INSERT INTO `sessions` VALUES('ci_session:714f195aadef7cdc824e552a7800e216', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785769321;csrf_token_essential|s:32:\"e671e759ce46556f5dbb35d1e47b2867\";_ci_previous_url|s:40:\"https://essential.test/backend/dashboard\";backendSession|s:32:\"d08024373f31120f572daf6682f0f582\";message|s:26:\"Buongiorno giorgio barone.\";class|s:26:\"light text-success fw-bold\";icon|s:37:\"<i class=\"fa-solid fa-handshake\"></i>\";__ci_vars|a:3:{s:7:\"message\";s:3:\"old\";s:5:\"class\";s:3:\"old\";s:4:\"icon\";s:3:\"old\";}');
INSERT INTO `sessions` VALUES('ci_session:718b615b877f8bbab4a9ecb04b468c37', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786027176;csrf_token_essential|s:32:\"abe2528f7864b9a847bb322b6726d9ce\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:737144b4ba830eba88d897ad2518922a', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785859928;csrf_token_essential|s:32:\"f955bbb3604a5036dca500264448ec8d\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"563de838379921d55fa34d99f52aa59c\";');
INSERT INTO `sessions` VALUES('ci_session:7e2f0cc405ff99ecf15b802b5f499524', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785848802;csrf_token_essential|s:32:\"a1ae13a57aa38dcec7a2fecc9d35d665\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"4325b00bb8eb94b0e5fe5d2044eb738e\";');
INSERT INTO `sessions` VALUES('ci_session:856f4d2f4170f8d53dc23c08649f8687', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786038123;csrf_token_essential|s:32:\"72b9d3709961ecf0611d05c726212894\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"2d4df4b587a60a1fe36a1adef896824b\";');
INSERT INTO `sessions` VALUES('ci_session:874d6c1680bb86ac9567eef2165f4c38', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785945104;csrf_token_essential|s:32:\"f8f064345fbbc29a933693a0f5a5915e\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"8b8e4388a67403dfc578997d52a5d94f\";intended_url|s:45:\"https://essential.test/backend/admins/showAll\";message|s:33:\"Effettuare il login per accedere.\";__ci_vars|a:3:{s:7:\"message\";s:3:\"new\";s:5:\"class\";s:3:\"new\";s:4:\"icon\";s:3:\"new\";}class|s:25:\"light text-danger fw-bold\";icon|s:48:\"<i class=\"fa-solid fa-triangle-exclamation\"></i>\";');
INSERT INTO `sessions` VALUES('ci_session:88b59dfa41d70e3838a7f091b44b1c21', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785851552;csrf_token_essential|s:32:\"5bb797f4be728483aecb2cf156a2defe\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";');
INSERT INTO `sessions` VALUES('ci_session:8a82c99fd6934779ab58c014d0bb803b', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785770712;csrf_token_essential|s:32:\"5e63a1d4f1cea9cfcc87dab3127a923e\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"d08024373f31120f572daf6682f0f582\";');
INSERT INTO `sessions` VALUES('ci_session:92c459840a8e789f1cc87acc03dceee9', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786022525;csrf_token_essential|s:32:\"dfe310f9491be1ed0abdde2398daf341\";_ci_previous_url|s:37:\"https://essential.test/backend/groups\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:94cacf0bea25a965250db8be415dcff3', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786037736;csrf_token_essential|s:32:\"171ae440ca28457cdd031f2e5dd953b5\";_ci_previous_url|s:35:\"https://essential.test/backend/auth\";backendSession|s:32:\"866c7bf703fd75b71e1681164c68cca0\";message|s:33:\"Effettuare il login per accedere.\";__ci_vars|a:3:{s:7:\"message\";s:3:\"old\";s:5:\"class\";s:3:\"old\";s:4:\"icon\";s:3:\"old\";}class|s:25:\"light text-danger fw-bold\";icon|s:48:\"<i class=\"fa-solid fa-triangle-exclamation\"></i>\";');
INSERT INTO `sessions` VALUES('ci_session:95fb905d0b5012294e7b63ae9f475471', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785849160;csrf_token_essential|s:32:\"f6f92a0468d097e252f556bf045b47cf\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"4325b00bb8eb94b0e5fe5d2044eb738e\";');
INSERT INTO `sessions` VALUES('ci_session:9b3b555a0b41df93c41cb941c2f868c5', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786026391;csrf_token_essential|s:32:\"d3d22286c80e483cf40fd9194d06a4bc\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:9f34ea16756eeaaa4b08b0935045ed89', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786026832;csrf_token_essential|s:32:\"b433f1f7e1a61f887c6b6abb1808b759\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:b2e48fd9fffbd3f89c73597686815297', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785859352;csrf_token_essential|s:32:\"fc679b298581974385d2ef49d97dd9d6\";_ci_previous_url|s:79:\"https://essential.test/backend/admins/edit/3a6f4275-8b9e-41c4-bc2f-d3e1b7d6e4a5\";backendSession|s:32:\"563de838379921d55fa34d99f52aa59c\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:b649f77fa32f892664a0160f5e3be501', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785939919;csrf_token_essential|s:32:\"a35f21c0965db48425a5d47208fb471c\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"8b8e4388a67403dfc578997d52a5d94f\";');
INSERT INTO `sessions` VALUES('ci_session:b675984a1b8d8e03ee8a8304323457e8', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786032744;csrf_token_essential|s:32:\"8b50f487d666b0651b2811d256186118\";_ci_previous_url|s:38:\"https://essential.test/backend/account\";backendSession|s:32:\"e11766a1bbcc5049262d2e6eda27ff57\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:b67b9ec8fd98da95a2880e4e29b3bbb4', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785854198;csrf_token_essential|s:32:\"15e6d22cbaeb24c281b4af6b771a6fbf\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";');
INSERT INTO `sessions` VALUES('ci_session:b6b4c41759292c14726466e78ac80d3e', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785941353;csrf_token_essential|s:32:\"e4d0cedd9fdef0682048e6e0e779eb6b\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"8b8e4388a67403dfc578997d52a5d94f\";');
INSERT INTO `sessions` VALUES('ci_session:b82ff34ca0e7a4409ea26849b93a9fe6', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785946277;csrf_token_essential|s:32:\"397c4f022c0ac21e4ef9dafbfd9d2375\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"4a459f41c69673074e2e5dcfbaf75c12\";');
INSERT INTO `sessions` VALUES('ci_session:bd5c55e38948c2296931103a234cf0fb', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786022211;csrf_token_essential|s:32:\"ff22312ab7891481936b8a2869352efd\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:c045cf9eda3a83693f778265255471b2', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785854816;csrf_token_essential|s:32:\"1f022361fe5b2bd9b7aa2c505012c0e4\";_ci_previous_url|s:45:\"https://essential.test/backend/account/tokens\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:c0fdd46b84697ca7837335777eeaedbe', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785849861;csrf_token_essential|s:32:\"ed774b8e824c039d7aeebbea8eda3523\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";');
INSERT INTO `sessions` VALUES('ci_session:cf66d6db4983fe639700ae540a777804', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785858296;csrf_token_essential|s:32:\"c14700b27597aa429b06a0e05c0238da\";_ci_previous_url|s:41:\"https://essential.test/backend/admins/add\";backendSession|s:32:\"563de838379921d55fa34d99f52aa59c\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:d478690d87ae84d8ff3d740a2f589f5d', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786021843;csrf_token_essential|s:32:\"86baa2f02b102e4daf68a9b7c035e57a\";_ci_previous_url|s:37:\"https://essential.test/backend/audits\";backendSession|s:32:\"0d847efb918d52b128211767c3e58e24\";');
INSERT INTO `sessions` VALUES('ci_session:d8a951c4f03bde1adf73c84e10b6ae0a', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785868390;csrf_token_essential|s:32:\"9dd3003510400ccf05291beef7f60093\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"fca99ff32463ecca6db02931f58c4dfa\";');
INSERT INTO `sessions` VALUES('ci_session:da9deb62d19e50c5aacd22c811932663', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785763405;csrf_token_essential|s:32:\"54b57c4ac2c757dd9022c878a599bdb1\";_ci_previous_url|s:42:\"https://essential.test/backend/auth/verify\";auth_2fa_pending|a:3:{s:10:\"admin_uuid\";s:36:\"e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31\";s:10:\"rememberMe\";b:0;s:6:\"method\";s:5:\"email\";}');
INSERT INTO `sessions` VALUES('ci_session:db47301ab3b867b61fae2020d862cbaa', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785848353;csrf_token_essential|s:32:\"636a0537efd99e7a9594477b4dae12c5\";_ci_previous_url|s:40:\"https://essential.test/backend/dashboard\";backendSession|s:32:\"4325b00bb8eb94b0e5fe5d2044eb738e\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:e092548e8ad10936c4539a0f595d3bf9', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785858611;csrf_token_essential|s:32:\"f9ca4780cd9f1f8c01bce600dc28652d\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";backendSession|s:32:\"563de838379921d55fa34d99f52aa59c\";');
INSERT INTO `sessions` VALUES('ci_session:e29ef40b5663b5ff56c1dc63e2184fb5', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785853365;csrf_token_essential|s:32:\"f79f7149f01f6a6c6622da2886276fbf\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";');
INSERT INTO `sessions` VALUES('ci_session:e541bfa0973de107db21669edeaccfff', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785768518;csrf_token_essential|s:32:\"c620fe00fd78513dc6682363f3d72d68\";_ci_previous_url|s:35:\"https://essential.test/backend/auth\";backendSession|s:32:\"f30af39a5bf20fec010add532a493f56\";message|s:33:\"Effettuare il login per accedere.\";class|s:25:\"light text-danger fw-bold\";icon|s:48:\"<i class=\"fa-solid fa-triangle-exclamation\"></i>\";__ci_vars|a:3:{s:7:\"message\";s:3:\"old\";s:5:\"class\";s:3:\"old\";s:4:\"icon\";s:3:\"old\";}intended_url|s:40:\"https://essential.test/backend/dashboard\";');
INSERT INTO `sessions` VALUES('ci_session:ebfc4c03308d7375c2e72e6eaf4742e2', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1786037633;csrf_token_essential|s:32:\"9fc8dd92259e71bb5a4fc15ef9305aaa\";_ci_previous_url|s:35:\"https://essential.test/backend/auth\";backendSession|s:32:\"bea0706c1e4554d5f3edbbfa2deaa3ea\";message|s:33:\"Effettuare il login per accedere.\";__ci_vars|a:3:{s:7:\"message\";s:3:\"old\";s:5:\"class\";s:3:\"old\";s:4:\"icon\";s:3:\"old\";}class|s:25:\"light text-danger fw-bold\";icon|s:48:\"<i class=\"fa-solid fa-triangle-exclamation\"></i>\";');
INSERT INTO `sessions` VALUES('ci_session:f066e45977b075b39477e9a8ba4120e0', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785771638;csrf_token_essential|s:32:\"f505b22e3c0f775f7d01340b5d79b655\";_ci_previous_url|s:79:\"https://essential.test/backend/tokens?uuid=e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31\";backendSession|s:32:\"d08024373f31120f572daf6682f0f582\";');
INSERT INTO `sessions` VALUES('ci_session:f2fe3c5877c53e2735d633053dfae0ab', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785936623;csrf_token_essential|s:32:\"cfb005b03aa1c47d0db911ce42a72d34\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"5c8c553613730a2ebc2324bd09b2b032\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:f6f88470523235fb50e6e8a8ae63bf7b', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785855841;csrf_token_essential|s:32:\"dc07fda739852564c2d250a63a258cb6\";_ci_previous_url|s:37:\"https://essential.test/backend/tokens\";');
INSERT INTO `sessions` VALUES('ci_session:faeca39817d06f5d94337d4d2d384f2d', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785857282;csrf_token_essential|s:32:\"01176d1a6d654531985a92502bfd0980\";_ci_previous_url|s:47:\"https://essential.test/backend/account/security\";backendSession|s:32:\"563de838379921d55fa34d99f52aa59c\";');

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `class_key_unique` (`class`,`key`),
  KEY `idx_class` (`class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
