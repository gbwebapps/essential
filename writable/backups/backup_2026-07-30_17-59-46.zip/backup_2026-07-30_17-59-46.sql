/* Backup Database generato il 2026-07-30 17:59:46 */

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `master` tinyint(1) NOT NULL DEFAULT '0',
  `group_id` int unsigned NOT NULL,
  `note` text COLLATE utf8mb4_general_ci,
  `password_hash` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `suspended_at` datetime DEFAULT NULL,
  `resetted_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `email` (`email`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email_2` (`email`),
  KEY `phone` (`phone`),
  KEY `status` (`status`),
  KEY `master` (`master`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `fk_admins_group_id` FOREIGN KEY (`group_id`) REFERENCES `admins_groups` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins` VALUES('3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', 'Francesca', 'Bianchi', 'francesca.bianchi@example.com', '+393001234563', '0', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', '2026-07-30 17:47:06', '2026-07-30 17:47:06', NULL, NULL);
INSERT INTO `admins` VALUES('4e8b3c1d-fa62-4935-bc71-2e5a9f4b8d63', 'Stefano', 'Colombo', 'stefano.colombo@example.com', '+393001234568', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('5217ce13-2414-4806-b6b3-e914876a7f60', 'Jason', 'Donaldson', 'giovanni.marini@example.com', '+394368824122', '1', '0', '1', 'Exercitationem dolor', NULL, '2026-07-30 16:28:59', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('5f2a1d7c-e9b4-4361-8c5f-9d3a7b6e84fa', 'Fabio', 'Bruno', 'fabio.bruno@example.com', '+393001234572', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('6d2a8f4c-1e9b-4375-ae82-93b5c1d6f47a', 'Roberto', 'Esposito', 'roberto.esposito@example.com', '+393001234566', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('7c4d5b92-f1a8-4e36-9b54-cf210a48b3e9', 'Mario', 'Rossi', 'mario.rossi@example.com', '+393001234561', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('7e1b5d9c-3a6f-4275-8b9e-c4a2f8d1e3b6', 'Davide', 'Costa', 'davide.costa@example.com', '+393001234576', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('8b9e1c7d-5a3b-462f-ad4c-1e9b5f2a7c1e', 'Luca', 'Rizzo', 'luca.rizzo@example.com', '+393001234578', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('9a5f2c8b-d3e1-4674-bf9e-1c7d5a3b62f4', 'Laura', 'Ricci', 'laura.ricci@example.com', '+393001234569', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('a6d4e2b8-f1c5-4973-bc8a-4d2e1f5b937c', 'Chiara', 'Gallo', 'chiara.gallo@example.com', '+393001234573', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('a83f9e1c-5d2b-4681-ad4e-72bf05c1d63a', 'Giuseppe', 'Verdi', 'giuseppe.verdi@example.com', '+393001234562', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('b0e3f7d1-c6a4-4893-bc2e-51da9f8b4c72', 'Anna', 'Russo', 'anna.russo@example.com', '+393001234565', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('bc5f9e1b-5d9c-43a6-8f42-758b9e1c7d5a', 'Andrea', 'Mancini', 'andrea.mancini@example.com', '+393001234580', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('c1f5b9d3-e2a7-4b61-8d4f-5c9a2e8b637d', 'Elena', 'Romano', 'elena.romano@example.com', '+393001234567', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('c4a2f8d1-e3b6-4927-bc5f-9e1b5d9c3a6f', 'Sara', 'Giordano', 'sara.giordano@example.com', '+393001234577', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('e3c9a5b7-2f1d-4862-ad7e-6b4c1f9e2a5d', 'Silvia', 'Greco', 'silvia.greco@example.com', '+393001234571', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'Giorgio Alessandro', 'Barone', 'gbwebapps@gmail.com', '+393519081161', '1', '1', '1', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', '2026-07-29 17:06:37', NULL, NULL, NULL);
INSERT INTO `admins` VALUES('f2c5a1e8-73b9-4d62-9a4f-1c8b5d3e76fa', 'Alessandro', 'Ferrari', 'alessandro.ferrari@example.com', '+393001234564', '1', '0', '2', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);
INSERT INTO `admins` VALUES('fd3a7c1e-9b5f-4628-ad12-5e4c8a7b3f91', 'Giulia', 'De Luca', 'giulia.deluca@example.com', '+393001234575', '1', '0', '3', NULL, '$2y$10$gFNsG60FJ6rJhdlMtd0h6.gX.rSbYfjf7oxLpKqgcP5v6M/c6Ud62', '2026-07-29 17:05:32', NULL, NULL, NULL, NULL);

DROP TABLE IF EXISTS `admins_2fa`;
CREATE TABLE `admins_2fa` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `method` enum('email','totp') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'email',
  `secret` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_method` (`admin_uuid`,`method`),
  KEY `idx_admin` (`admin_uuid`),
  KEY `idx_admin_enabled` (`admin_uuid`,`enabled`),
  CONSTRAINT `fk_admins_2fa_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_2fa` VALUES('1', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'email', NULL, '0');
INSERT INTO `admins_2fa` VALUES('2', '7c4d5b92-f1a8-4e36-9b54-cf210a48b3e9', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('3', 'a83f9e1c-5d2b-4681-ad4e-72bf05c1d63a', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('4', '3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('5', 'f2c5a1e8-73b9-4d62-9a4f-1c8b5d3e76fa', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('6', 'b0e3f7d1-c6a4-4893-bc2e-51da9f8b4c72', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('7', '6d2a8f4c-1e9b-4375-ae82-93b5c1d6f47a', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('8', 'c1f5b9d3-e2a7-4b61-8d4f-5c9a2e8b637d', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('9', '4e8b3c1d-fa62-4935-bc71-2e5a9f4b8d63', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('10', '9a5f2c8b-d3e1-4674-bf9e-1c7d5a3b62f4', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('12', 'e3c9a5b7-2f1d-4862-ad7e-6b4c1f9e2a5d', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('13', '5f2a1d7c-e9b4-4361-8c5f-9d3a7b6e84fa', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('14', 'a6d4e2b8-f1c5-4973-bc8a-4d2e1f5b937c', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('16', 'fd3a7c1e-9b5f-4628-ad12-5e4c8a7b3f91', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('17', '7e1b5d9c-3a6f-4275-8b9e-c4a2f8d1e3b6', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('18', 'c4a2f8d1-e3b6-4927-bc5f-9e1b5d9c3a6f', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('19', '8b9e1c7d-5a3b-462f-ad4c-1e9b5f2a7c1e', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('21', 'bc5f9e1b-5d9c-43a6-8f42-758b9e1c7d5a', 'email', NULL, '1');
INSERT INTO `admins_2fa` VALUES('23', '5217ce13-2414-4806-b6b3-e914876a7f60', 'email', NULL, '1');

DROP TABLE IF EXISTS `admins_2fa_attempts`;
CREATE TABLE `admins_2fa_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `method` enum('email','totp') COLLATE utf8mb4_general_ci NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_uuid` (`admin_uuid`,`method`,`timestamp`),
  CONSTRAINT `fk_user_2fa_attempts_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `admins_2fa_codes`;
CREATE TABLE `admins_2fa_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `code` char(6) COLLATE utf8mb4_general_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_uuid` (`admin_uuid`),
  CONSTRAINT `fk_admins_2fa_codes_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `admins_attempts`;
CREATE TABLE `admins_attempts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_attempts_lookup` (`admin_uuid`,`timestamp`),
  CONSTRAINT `fk_admins_attempts_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `admins_audits`;
CREATE TABLE `admins_audits` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Guest',
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin_uuid` (`admin_uuid`),
  KEY `idx_sezione` (`section`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admins_audits` VALUES('1', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', '2FA_REQUIRED', 'auth', 'Richiesto codice di verifica 2FA (email) giorgio barone', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 17:05:50');
INSERT INTO `admins_audits` VALUES('2', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato giorgio barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 17:06:15');
INSERT INTO `admins_audits` VALUES('3', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'UPDATE_DATA', 'account', 'Aggiornamento dati generali Giorgio Alessandro Barone', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 17:06:37');
INSERT INTO `admins_audits` VALUES('4', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'ACTIVATE_NONE', 'account', 'Impostazione metodo 2Fa Giorgio Alessandro Barone', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 17:06:45');
INSERT INTO `admins_audits` VALUES('5', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 17:24:21');
INSERT INTO `admins_audits` VALUES('6', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 19:40:21');
INSERT INTO `admins_audits` VALUES('7', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:02:24');
INSERT INTO `admins_audits` VALUES('8', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE_ADMIN', 'admins', 'Cestinato admin Marco Conti', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:02:36');
INSERT INTO `admins_audits` VALUES('9', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'RESTORE_ADMIN', 'admins', 'Ripristinato admin Giovanni Marini', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:02:51');
INSERT INTO `admins_audits` VALUES('10', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'RESTORE_ADMIN', 'admins', 'Ripristinato admin Marco Conti', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:03:00');
INSERT INTO `admins_audits` VALUES('11', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE_ADMIN', 'admins', 'Cestinato admin Marco Conti', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:03:19');
INSERT INTO `admins_audits` VALUES('12', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'DELETE_ADMIN', 'admins', 'Eliminazione admin Marco Conti', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:03:26');
INSERT INTO `admins_audits` VALUES('13', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:48:09');
INSERT INTO `admins_audits` VALUES('14', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE', 'admins', 'Cestinato admin Giovanni Marini', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:48:28');
INSERT INTO `admins_audits` VALUES('15', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'RESTORE_DELETE', 'admins', 'Ripristinato admin Giovanni Marini', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:49:18');
INSERT INTO `admins_audits` VALUES('16', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE', 'admins', 'Cestinato admin Martina Moretti', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:49:31');
INSERT INTO `admins_audits` VALUES('17', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'HARD_DELETE', 'admins', 'Eliminazione admin Martina Moretti', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:49:40');
INSERT INTO `admins_audits` VALUES('18', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE', 'admins', 'Cestinato admin Giovanni Marini', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:50:35');
INSERT INTO `admins_audits` VALUES('19', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'ADD', 'admins', 'Aggiunta admin Demetrius Grimes', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-29 20:52:22');
INSERT INTO `admins_audits` VALUES('20', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 14:36:48');
INSERT INTO `admins_audits` VALUES('21', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 14:54:45');
INSERT INTO `admins_audits` VALUES('22', '3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', 'francesca.bianchi@example.com', '2FA_REQUIRED', 'auth', 'Richiesto codice di verifica 2FA (email) Francesca Bianchi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 14:59:30');
INSERT INTO `admins_audits` VALUES('23', '3d6b2f8a-9c4e-4172-8b1a-d0f3c5e7b649', 'francesca.bianchi@example.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Francesca Bianchi ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 14:59:53');
INSERT INTO `admins_audits` VALUES('24', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 15:03:03');
INSERT INTO `admins_audits` VALUES('25', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE', 'admins', 'Cestinato admin Stefano Colombo', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 15:11:27');
INSERT INTO `admins_audits` VALUES('26', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 15:48:19');
INSERT INTO `admins_audits` VALUES('27', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'RESTORE_DELETE', 'admins', 'Ripristinato admin Giovanni Marini', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:08:29');
INSERT INTO `admins_audits` VALUES('28', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'RESTORE_DELETE', 'admins', 'Ripristinato admin Stefano Colombo', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:08:42');
INSERT INTO `admins_audits` VALUES('29', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'EDIT', 'admins', 'Aggiornamento admin Giovanni Marini', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:09:43');
INSERT INTO `admins_audits` VALUES('30', '1b7d6e4a-c5f9-4283-9b4e-8d2a1c5f3b76', 'stefano.colombo.1985@example.com', '2FA_REQUIRED', 'auth', 'Richiesto codice di verifica 2FA (email) Giovanni Marini', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:10:00');
INSERT INTO `admins_audits` VALUES('31', '1b7d6e4a-c5f9-4283-9b4e-8d2a1c5f3b76', 'stefano.colombo.1985@example.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giovanni Marini ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:10:12');
INSERT INTO `admins_audits` VALUES('32', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:22:40');
INSERT INTO `admins_audits` VALUES('33', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE', 'admins', 'Cestinato admin Giovanni Marini', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:23:29');
INSERT INTO `admins_audits` VALUES('34', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE', 'admins', 'Cestinato admin Demetrius Grimes', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:28:18');
INSERT INTO `admins_audits` VALUES('35', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'ADD', 'admins', 'Aggiunta admin Jason Donaldson', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:28:59');
INSERT INTO `admins_audits` VALUES('36', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'RESTORE_DELETE', 'admins', 'Ripristinato admin Demetrius Grimes', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:29:31');
INSERT INTO `admins_audits` VALUES('37', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'ADD', 'admins', 'Aggiunta admin Chaney Webb', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:31:10');
INSERT INTO `admins_audits` VALUES('38', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'RESTORE_DELETE', 'admins', 'Ripristinato admin Giovanni Marini', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:31:23');
INSERT INTO `admins_audits` VALUES('39', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE', 'admins', 'Cestinato admin Giovanni Marini', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 16:33:05');
INSERT INTO `admins_audits` VALUES('40', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'LOGIN_SUCCESS', 'auth', 'Accesso effettuato Giorgio Alessandro Barone ', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 17:44:28');
INSERT INTO `admins_audits` VALUES('41', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE', 'admins', 'Cestinato admin Demetrius Grimes', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 17:45:24');
INSERT INTO `admins_audits` VALUES('42', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'HARD_DELETE', 'admins', 'Eliminazione admin Demetrius Grimes', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 17:45:28');
INSERT INTO `admins_audits` VALUES('43', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'HARD_DELETE', 'admins', 'Eliminazione admin Giovanni Marini', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 17:45:33');
INSERT INTO `admins_audits` VALUES('44', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'SOFT_DELETE', 'admins', 'Cestinato admin Chaney Webb', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 17:46:13');
INSERT INTO `admins_audits` VALUES('45', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'HARD_DELETE', 'admins', 'Eliminazione admin Chaney Webb', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 17:46:20');
INSERT INTO `admins_audits` VALUES('46', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', 'gbwebapps@gmail.com', 'CHANGE_STATUS', 'admins', 'Aggiornamento status Francesca Bianchi', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-30 17:47:06');

DROP TABLE IF EXISTS `admins_groups`;
CREATE TABLE `admins_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_groups` VALUES('1', 'Administrator', 'Gestione operativa completa, configurazioni e supervisione utenti', '2026-07-29 17:05:32', NULL);
INSERT INTO `admins_groups` VALUES('2', 'Editor Manager', 'Gestione e pubblicazione dei contenuti, messaggi e schede informative', '2026-07-29 17:05:32', NULL);
INSERT INTO `admins_groups` VALUES('3', 'Operator Support', 'Visualizzazione dati, assistenza clienti e gestione ticket', '2026-07-29 17:05:32', NULL);

DROP TABLE IF EXISTS `admins_groups_permissions`;
CREATE TABLE `admins_groups_permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int unsigned NOT NULL,
  `permission` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_group_permission` (`group_id`,`permission`),
  CONSTRAINT `fk_group_permissions_group_id` FOREIGN KEY (`group_id`) REFERENCES `admins_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_groups_permissions` VALUES('8', '1', 'messages_delete');
INSERT INTO `admins_groups_permissions` VALUES('5', '1', 'messages_index');
INSERT INTO `admins_groups_permissions` VALUES('7', '1', 'messages_show');
INSERT INTO `admins_groups_permissions` VALUES('6', '1', 'messages_showall');
INSERT INTO `admins_groups_permissions` VALUES('4', '1', 'users_delete');
INSERT INTO `admins_groups_permissions` VALUES('1', '1', 'users_index');
INSERT INTO `admins_groups_permissions` VALUES('3', '1', 'users_show');
INSERT INTO `admins_groups_permissions` VALUES('2', '1', 'users_showall');
INSERT INTO `admins_groups_permissions` VALUES('11', '2', 'messages_index');
INSERT INTO `admins_groups_permissions` VALUES('13', '2', 'messages_show');
INSERT INTO `admins_groups_permissions` VALUES('12', '2', 'messages_showall');
INSERT INTO `admins_groups_permissions` VALUES('9', '2', 'users_index');
INSERT INTO `admins_groups_permissions` VALUES('10', '2', 'users_show');
INSERT INTO `admins_groups_permissions` VALUES('15', '3', 'messages_index');
INSERT INTO `admins_groups_permissions` VALUES('16', '3', 'messages_show');
INSERT INTO `admins_groups_permissions` VALUES('14', '3', 'users_index');

DROP TABLE IF EXISTS `admins_permissions`;
CREATE TABLE `admins_permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `permission` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `allow` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_admin_permission` (`admin_uuid`,`permission`),
  CONSTRAINT `fk_admins_permissions_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `admins_tokens`;
CREATE TABLE `admins_tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `token_hash` varchar(64) COLLATE utf8mb4_general_ci NOT NULL,
  `token_create` datetime NOT NULL,
  `token_expire` datetime NOT NULL,
  `token_type` enum('cookie','session','activation') COLLATE utf8mb4_general_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_uuid` (`admin_uuid`),
  KEY `token_hash` (`token_hash`),
  KEY `token_create` (`token_create`),
  KEY `token_expire` (`token_expire`),
  KEY `token_type` (`token_type`),
  CONSTRAINT `fk_admins_tokens_admin_uuid` FOREIGN KEY (`admin_uuid`) REFERENCES `admins` (`uuid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins_tokens` VALUES('14', '5217ce13-2414-4806-b6b3-e914876a7f60', 'cc347a9cfb25d20de47c709fb0d8dd22cb5cc3271c6a1c46dfae841d30f50b9b', '2026-07-30 16:28:59', '2026-07-30 22:28:59', 'activation', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '127.0.0.1');
INSERT INTO `admins_tokens` VALUES('17', 'e4eaaaf2-d142-4f8b-8cf6-4d8a1fc27b31', '5b9c34b3bae0580405b871feb70a668148ad99999d4be771dbcc02ef1b79a350', '2026-07-30 17:44:28', '2026-07-30 18:19:46', 'session', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '127.0.0.1');

DROP TABLE IF EXISTS `images`;
CREATE TABLE `images` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entity` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `entity_uuid` char(36) COLLATE utf8mb4_general_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `is_cover` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_images_entity_uuid` (`entity`,`entity_uuid`),
  KEY `idx_images_cover` (`entity`,`entity_uuid`,`is_cover`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(128) COLLATE utf8mb4_general_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `timestamp` int unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `sessions` VALUES('ci_session:18595e98caa0220a810efcbd23dd87d3', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785422207;csrf_token_essential|s:32:\"a82fb84dacb78d5737e46a43496d91b2\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"764f5db7a9f7238161c50c5a227c4e31\";');
INSERT INTO `sessions` VALUES('ci_session:2573a494eb59677c57ae0831423343b7', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785419294;csrf_token_essential|s:32:\"afb4147e2e0e5a16ad7e38be39c20262\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"cca9834ad39dd64db0cbed3f665cee9e\";');
INSERT INTO `sessions` VALUES('ci_session:280df0bd889e4ce02dd4b903c78645a5', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785420500;csrf_token_essential|s:32:\"4b1ec3035a42d1736163102dd98077b8\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"4605954ad05bced1667c1357abde8e3b\";');
INSERT INTO `sessions` VALUES('ci_session:462851bb9edca08f3f6d719969eae326', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785416064;csrf_token_essential|s:32:\"ca9079e742e4cb0b12899ed09be94aea\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"85dc9f01a9d8355eef25d93f4dfcbf39\";');
INSERT INTO `sessions` VALUES('ci_session:4ee5099a7de6ee7a3866655e41ee6d4a', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785417270;csrf_token_essential|s:32:\"37b359dab107d9852341e4463165e683\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"cca9834ad39dd64db0cbed3f665cee9e\";');
INSERT INTO `sessions` VALUES('ci_session:520b24bb0a97b4e84c369757356b1803', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"ff172bf8cfc3366f6a418554b74c1b5e\";__ci_last_regenerate|i:1785340294;_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"346480154a77bda6c179797e5a939966\";');
INSERT INTO `sessions` VALUES('ci_session:53a895c372d1db1a26d1728e49a0c5b0', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785350884;csrf_token_essential|s:32:\"89b6acd44c83eb4d250411bf3c4f488c\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"e4ebcff32a32c691f27128fdd454b416\";');
INSERT INTO `sessions` VALUES('ci_session:646067615641b1e427ce305c16cb8c96', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785348127;csrf_token_essential|s:32:\"b965c5df0713a2e6793d16f43081e64c\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"0e4915f414b43357c36422c399967a16\";');
INSERT INTO `sessions` VALUES('ci_session:6f472a087a4accaff241d99926e91ea3', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"99968d723413870a220c362ce864d881\";__ci_last_regenerate|i:1785339915;_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"346480154a77bda6c179797e5a939966\";');
INSERT INTO `sessions` VALUES('ci_session:876dc8155807f262f0dad7238b6851b4', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785426059;csrf_token_essential|s:32:\"0d3f8ffd6645a5746cf06b40d71e91e6\";_ci_previous_url|s:37:\"https://essential.test/backend/audits\";backendSession|s:32:\"764f5db7a9f7238161c50c5a227c4e31\";message|s:33:\"Effettuare il login per accedere.\";__ci_vars|a:3:{s:7:\"message\";s:3:\"new\";s:5:\"class\";s:3:\"new\";s:4:\"icon\";s:3:\"new\";}class|s:6:\"danger\";icon|s:48:\"<i class=\"fa-solid fa-triangle-exclamation\"></i>\";');
INSERT INTO `sessions` VALUES('ci_session:8b7e7077d209107f870ebc838d38c599', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785415562;csrf_token_essential|s:32:\"2ddeccf4c471eaea3bff4636a232e758\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"85dc9f01a9d8355eef25d93f4dfcbf39\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:aea6e33759f885f2a72d602db531a08d', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"9d1fa4e0e0633c9ec1c984eee0e37a63\";__ci_last_regenerate|i:1785340757;_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"346480154a77bda6c179797e5a939966\";');
INSERT INTO `sessions` VALUES('ci_session:c11742d5d69b9b10da3ec31b9bf2ab88', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785427054;csrf_token_essential|s:32:\"cefa3f368b5e27806d8f168a58e1d4f2\";_ci_previous_url|s:36:\"https://essential.test/backend/tools\";backendSession|s:32:\"9ba29f5ecf01f4f0893fa94e18b71521\";');
INSERT INTO `sessions` VALUES('ci_session:c5338a19afad60eadeec7110318d9e87', '127.0.0.1', '4294967295', 'csrf_token_essential|s:32:\"ce679ae121286b6feb35afa34e88fb36\";__ci_last_regenerate|i:1785341064;_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"346480154a77bda6c179797e5a939966\";');
INSERT INTO `sessions` VALUES('ci_session:d5208866ce6236e60165a54034db5fd3', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785416900;csrf_token_essential|s:32:\"5cda163926e17781eac2b1edc096dc30\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"cca9834ad39dd64db0cbed3f665cee9e\";__ci_vars|a:0:{}');
INSERT INTO `sessions` VALUES('ci_session:e1189a088bb29af2879b77c80daacb22', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785427054;csrf_token_essential|s:32:\"ee1587734c9bb16cb09a34726bf67e52\";_ci_previous_url|s:37:\"https://essential.test/backend/audits\";backendSession|s:32:\"9ba29f5ecf01f4f0893fa94e18b71521\";');
INSERT INTO `sessions` VALUES('ci_session:f70815ab175847b44a03f21ebfb3035d', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785421195;csrf_token_essential|s:32:\"1efe6946a0dc3893f603f5147f1a68e8\";_ci_previous_url|s:40:\"https://essential.test/backend/dashboard\";backendSession|s:32:\"fd7436ef22bebb7e1be8ba668e7b1ea8\";message|s:27:\"Buongiorno Giovanni Marini.\";class|s:7:\"success\";icon|s:37:\"<i class=\"fa-solid fa-handshake\"></i>\";__ci_vars|a:3:{s:7:\"message\";s:3:\"old\";s:5:\"class\";s:3:\"old\";s:4:\"icon\";s:3:\"old\";}');
INSERT INTO `sessions` VALUES('ci_session:fb1544347efda9876fd994d25c5a4d7e', '127.0.0.1', '4294967295', '__ci_last_regenerate|i:1785421731;csrf_token_essential|s:32:\"cdf4d1b7307b86b29668a1824caabf7e\";_ci_previous_url|s:45:\"https://essential.test/backend/admins/showAll\";backendSession|s:32:\"764f5db7a9f7238161c50c5a227c4e31\";');

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `class_key_unique` (`class`,`key`),
  KEY `idx_class` (`class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
